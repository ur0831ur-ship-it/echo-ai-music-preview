# ECHO release v0.7 — deployment handoff

## What actually works
- Browser demo: procedural WAV composition, playback, and download (not semantic AI).
- Supabase client-side auth and cloud track features: implemented but require a project, schema and testing.
- Server-side generic AI adapter: scaffold only; **not** an ACE-Step native integration.

## Required external setup (cannot be completed with source files alone)
1. Create a Supabase project; run `schema.sql` and review RLS/storage policies.
2. Put the Supabase project URL and **publishable/anon** key in `config.js`. Never place service-role or music API keys in the browser.
3. Connect a Git repository to Netlify so Netlify Functions are deployed (static drag-and-drop alone is not a validated Functions deployment). Use `netlify.toml`.
4. Provision a licensed ACE-Step inference server. Obtain its *actual* endpoint/API contract and configure a corresponding server adapter. The generic `generate.mjs` is NOT ready for ACE-Step.
5. Set provider credentials in Netlify environment variables, test auth, quotas, timeout and generation end-to-end.
6. Before allowing public signups: implement provider-side usage quota/rate limiting, moderation, privacy and terms, monitoring and budget limits. Current code is NOT safe for unlimited public AI generation.

## Verification status
Source package assembled and syntax-checkable. No deployment, Supabase account, ACE-Step GPU, API credentials or end-to-end test has been performed by the assistant. Do not advertise AI generation as live.
