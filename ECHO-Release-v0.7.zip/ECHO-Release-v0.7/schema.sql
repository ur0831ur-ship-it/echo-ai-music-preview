-- Run in your own Supabase project's SQL editor.
create table if not exists public.tracks (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id) on delete cascade,
 title text not null check(char_length(title) between 1 and 150),
 prompt text not null default '', genre text not null default '',
 moods text[] not null default '{}', storage_path text not null unique,
 source text not null default 'demo' check(source in ('demo','ai')),
 is_public boolean not null default false,
 created_at timestamptz not null default now()
);
create index if not exists tracks_public_idx on public.tracks (created_at desc) where is_public = true;
alter table public.tracks enable row level security;
create policy "read public or own tracks" on public.tracks for select to authenticated,anon using (is_public or (select auth.uid())=owner_id);
create policy "insert own tracks" on public.tracks for insert to authenticated with check ((select auth.uid())=owner_id and storage_path like ((select auth.uid())::text || '/%'));
create policy "update own tracks" on public.tracks for update to authenticated using ((select auth.uid())=owner_id) with check ((select auth.uid())=owner_id and storage_path like ((select auth.uid())::text || '/%'));
create policy "delete own tracks" on public.tracks for delete to authenticated using ((select auth.uid())=owner_id);
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values ('tracks','tracks',false,10000000,array['audio/wav','audio/mpeg']) on conflict(id) do nothing;
create policy "read own or public track audio" on storage.objects for select to authenticated,anon using (bucket_id='tracks' and exists (select 1 from public.tracks t where t.storage_path=name and (t.is_public or t.owner_id=(select auth.uid()))));
create policy "upload to own folder" on storage.objects for insert to authenticated with check (bucket_id='tracks' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy "delete own audio" on storage.objects for delete to authenticated using (bucket_id='tracks' and (storage.foldername(name))[1]=(select auth.uid())::text);
