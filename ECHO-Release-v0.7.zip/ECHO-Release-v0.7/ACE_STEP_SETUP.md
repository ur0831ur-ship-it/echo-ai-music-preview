# ACE-Step integration plan (not connected yet)

This package preserves the working offline demo and Supabase-backed UI from v0.4. It does **not** claim a live ACE-Step connection. ACE-Step model weights alone do not provide a hosted API or guaranteed free GPU.

## To activate real generation
1. Obtain a legally usable ACE-Step 1.5 inference deployment with a documented HTTPS endpoint and permission to use it from your app. Confirm its API schema, authentication, duration limits and costs.
2. Implement a server-side adapter matching that deployment. The included `netlify/functions/generate.mjs` currently uses a generic provider contract, **not** ACE-Step's native API. Never put secrets in `config.js` or browser code.
3. Set Supabase URL and public anon key in `config.js`, create Supabase tables/policies using `schema.sql`, configure auth redirect URLs and storage permissions. Put server secrets in Netlify environment variables.
4. Deploy via Git/Netlify build pipeline with Functions enabled. Simple static file uploads may omit Functions.
5. Test sign-up, RLS access, generation limits, timeouts, private audio, copyright/voice misuse handling, and mobile playback. Use asynchronous jobs for generation that exceeds Netlify function execution time.

## Current verified state
Source files and ZIP are generated. No credentials, GPU endpoint or deployment access are available here. Thus real generation, cloud accounts and live deployment remain unverified.
