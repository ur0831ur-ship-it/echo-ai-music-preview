// Server-side adapter for a licensed music generation service.
// Provider contract: POST MUSIC_API_URL with JSON settings and Bearer MUSIC_API_KEY;
// response JSON {audioBase64: string, mimeType: 'audio/wav'|'audio/mpeg', title?: string}.
// Adapt this function to your chosen provider's real API before enabling production.
export default async (request) => {
 const json=(status,obj)=>new Response(JSON.stringify(obj),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
 if(request.method!=='POST')return json(405,{error:'POST only'});
 const {SUPABASE_URL,SUPABASE_ANON_KEY,MUSIC_API_URL,MUSIC_API_KEY}=process.env;
 if(!SUPABASE_URL||!SUPABASE_ANON_KEY||!MUSIC_API_URL||!MUSIC_API_KEY)return json(503,{error:'AI音楽生成APIはまだ設定されていません。管理者による接続が必要です。'});
 const token=(request.headers.get('authorization')||'').replace(/^Bearer /,'');if(!token)return json(401,{error:'ログインが必要です。'});
 try{
  const auth=await fetch(SUPABASE_URL+'/auth/v1/user',{headers:{apikey:SUPABASE_ANON_KEY,authorization:'Bearer '+token}});if(!auth.ok)return json(401,{error:'認証に失敗しました。'});
  const body=await request.json();if(typeof body.prompt!=='string'||!body.prompt.trim()||body.prompt.length>1200||!Number.isFinite(body.tempo)||body.tempo<40||body.tempo>220||typeof body.lyrics!=='string'||body.lyrics.length>5000||!Array.isArray(body.moods)||body.moods.length>12)return json(400,{error:'入力内容を確認してください。'});
  const payload={prompt:body.prompt,genre:String(body.genre||'Ambient').slice(0,40),moods:body.moods.map(x=>String(x).slice(0,30)),tempo:body.tempo,vocal:['instrumental','female','male'].includes(body.vocal)?body.vocal:'instrumental',lyrics:body.lyrics};
  const res=await fetch(MUSIC_API_URL,{method:'POST',headers:{authorization:'Bearer '+MUSIC_API_KEY,'content-type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(25000)});if(!res.ok)return json(502,{error:'音楽生成サービスがリクエストを処理できませんでした。'});
  const data=await res.json();if(!['audio/wav','audio/mpeg'].includes(data.mimeType)||typeof data.audioBase64!=='string'||data.audioBase64.length>9_000_000)return json(502,{error:'音楽生成サービスから対応形式の音源が返されませんでした。'});
  return json(200,{audioBase64:data.audioBase64,mimeType:data.mimeType,title:typeof data.title==='string'?data.title.slice(0,100):'ECHO AI Track'});
 }catch(e){return json(502,{error:e.name==='TimeoutError'?'生成サービスがタイムアウトしました。':'音楽生成処理に失敗しました。'});}
};
export const config={path:'/.netlify/functions/generate'};
