// Paste only your public Supabase project URL and publishable/anon key here.
// NEVER put service_role keys or AI provider secrets in browser code.
export const SUPABASE_URL = '';
export const SUPABASE_ANON_KEY = '';
