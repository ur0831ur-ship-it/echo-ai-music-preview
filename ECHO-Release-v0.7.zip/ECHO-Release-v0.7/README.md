# ECHO Fullstack v0.4

## Included
- Responsive black/violet studio; offline procedural WAV demo (NOT semantic text-to-music AI)
- Supabase email auth, private cloud audio storage, personal library, public community feed, playback, deletion
- Netlify server function adapter for a separately licensed music-generation provider

## Setup
1. Create your own Supabase project. Run `schema.sql` in its SQL editor. Configure email auth and allowed site URL/redirect URLs for your Netlify site.
2. Set `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `config.js` (these are public client credentials; NEVER put a service role key here).
3. Deploy the **contents** of this folder through Netlify with Git/CLI/build deployment that supports Netlify Functions. Static drag-and-drop may not deploy functions; the demo and UI can still load, but AI function won't run.
4. For genuine AI generation, select a licensed music-generation provider and adapt `netlify/functions/generate.mjs` to its real request/response contract. Set Netlify environment variables `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `MUSIC_API_URL`, `MUSIC_API_KEY`. The current adapter expects a JSON POST response `{audioBase64,mimeType,title}`; it is not a ready-made integration with any named provider. Never expose MUSIC_API_KEY in the frontend.
5. Test signup/email verification, private access, public playback, deletion, file size limits, and provider billing before inviting users. Add rate limiting, abuse prevention, moderation, usage quotas and terms/privacy policy before public launch. AI requests may exceed synchronous function timeout; production may need asynchronous job + polling + storage instead of base64 responses.

## Security / limitations
- Generated music may require licensing and rights review. Don't clone identifiable singers' voices or upload others' copyrighted tracks without permission.
- Supabase RLS protects metadata; private bucket signed URLs expire after one hour. File upload requires login.
- `schema.sql` is intended for a new project; policy names may conflict if run repeatedly.
- Demo creates simple procedural tones, not real generative AI. Full production functionality depends on external credentials and provider implementation.

See ACE_STEP_SETUP.md for ACE-Step 1.5 integration limitations.
